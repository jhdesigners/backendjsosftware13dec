<table border='1'>
    <tr>
        <td>
            Verification Code
        </td>
        <td>
            <?php echo e($code); ?>

        </td>
    <tr>
</table><?php /**PATH C:\xampp\htdocs\joyndigital_transworld_facebook\middle\resources\views/mail.blade.php ENDPATH**/ ?>