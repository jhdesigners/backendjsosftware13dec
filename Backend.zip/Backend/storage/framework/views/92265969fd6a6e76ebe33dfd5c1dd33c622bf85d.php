<table border='1'>
    <tr>
        <td>
            Verification Code
        </td>
        <td>
            <?php echo e($code); ?>

        </td>
    <tr>
</table><?php /**PATH /home/q75gxm6ez3uc/public_html/middle/resources/views/mail.blade.php ENDPATH**/ ?>